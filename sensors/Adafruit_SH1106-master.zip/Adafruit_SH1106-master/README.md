Adafruit library port for SH1106 I2C OLED displays.
