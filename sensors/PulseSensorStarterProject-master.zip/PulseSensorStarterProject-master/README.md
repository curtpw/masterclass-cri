
![logo](https://avatars0.githubusercontent.com/u/7002937?v=3&s=200)



## Getting Started Code / <a href="http://www.pulsesensor.com">PulseSensor</a>  & <a href="http://arduino.cc/"> "Arduino"</a>

[![Alt text](video-play.png)](https://www.youtube.com/watch?v=82T_zBZQkOE)




![ScreenShot](screenshot-threshold-arrows.png)
* Newbie-friendly code.   
* Live visualization of Raw Pulse Signal in Arduino's cool "Serial Plotter".


![Arduino PulseSensor](Arduino-LEDonPin13-PulseSensor-Pic.jpg)
* Blink an LED (on Pin 13) with your heartbeat!  💓


![Arduino PulseSensor](connections.png)
* A great first-step in troubleshooting your circuit, connections, and project!

------------------------------------------------------
#####  Legal:  PulseSensor.com™ World Famous Electronics llc. in Brooklyn, NY. USA
------------------------------------------------------
Made Something Awesome With the PulseSensor Code?   Send Us Some PayPal Love. ♥︎  
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg?style=plastic)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=KE4DZA5E9AJQ4) 
